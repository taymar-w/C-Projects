#include<iostream>
#include <string>
#include <cmath>
using namespace std;

class Person {
public:
	int age, weight, height;
	string name;
	Person( string n, int a, int w, int h) { name = n; age = a; weight = w; height = h; }
	Person(){}
	~Person(){}
};
class Heap {
public:
	
	Person * A;
	
	int last = -1;
	Heap(int asize) {
		A = new Person [asize];
	}
	int getParentIndex(int childIndex) {
		if (childIndex % 2 == 0) return childIndex / 2 - 1;
		else return childIndex / 2;
	}
	int getChildL(int parentIndex) {
		return 2 * parentIndex + 1;
	}
	int getChildR(int parentIndex) {
		return 2 * parentIndex + 2;
	}

	void Insert(string n, int a, int w, int h) {
		Person x(n,a,w,h);
		last++;
		A[last] = x;
		Heapify(last);
	}
	void Heapify(int childIndex) {
		int parentIndex = getParentIndex(childIndex);
		while (parentIndex >= 0 && childIndex >0)
		{
			if (A[childIndex].name > A[parentIndex].name) {
				Person temp = A[parentIndex];
				A[parentIndex] = A[childIndex];
				A[childIndex] = temp;
			}
			childIndex = parentIndex;
			parentIndex = getParentIndex(parentIndex);
		}
	}
	void Delete(string n, int a, int w, int h) {
		Person x(n, a, w, h);
		int index = -1;
		for (int i = 0; i <= last; i++) {
			if (A[i].name == x.name) { index = i; break; }
		}
		if (index == -1) { cout << "Element not found" << endl; }
		Person temp("", 0, 0, 0) ;
		 temp = A[index];
		A[index] = A[last];
		A[last] = temp;
		last--;
		HeapifyDown(index);
	}
	void HeapifyDown(int parentIndex) {
		while (true) {
			int largest = parentIndex;
			int childLindex = getChildL(parentIndex);
			int childRindex = getChildR(parentIndex);
			if (childLindex <= last && A[childLindex].name > A[largest].name) {
				largest = childLindex;
			}
			if (childRindex <= last && A[childRindex].name > A[largest].name) {
				largest = childRindex;
			}

			if (largest != parentIndex) {
				Person temp = A[parentIndex];
				A[parentIndex] = A[largest];
				A[largest] = temp;

				parentIndex = largest;
			}
			else {
				break;
			}
		}
	}
	void Print() {
		for (int i = 0; i <= last; i++) {
			cout << A[i].name << " ";
		}
		cout << endl;
	}
	void HeapSort() {
		for (int i = 0; i < 10; i++) {
			Delete(A[0].name,A[0].age,A[0].weight,A[0].height);
			
		}
	}
	void PrintAll() {
		for (int i = 0; i < 10; i++) {
			cout << A[i].name << " ";
		}
		cout << endl;
	}
};

int main() {

	Heap * heap = new Heap(11);
	
	cout << "HEAP SORT OF NAMES:\n---------------------------------\n";

	heap->Insert("Ed",23,190,5);	heap->Print();
	heap->Insert("Bill",26,150,5);	heap->Print();
	heap->Insert("Rick",30,120,5);	heap->Print();
	heap->Insert("Dan", 40, 122,5);	heap->Print();
	heap->Insert("Alan",20, 180,4);	heap->Print();
	heap->Insert("Tim",17,170,6);	heap->Print();
	heap->Insert("Gina",23,100,6);	heap->Print();
	heap->Insert("Marge",29,150,5);	heap->Print();
	heap->Insert("Wally",60,210,6);	heap->Print();
	heap->Insert("Sarah",20,190,4);	heap->Print();
	heap->Insert("Abby",10,105,5);	heap->Print(); 
	heap->Delete("Ed", 23, 190,5);	heap->Print();

	cout << "\nHEAP SORTED!:\n-----------------------------------\n";

	heap->HeapSort();				heap->PrintAll();
	

	getchar();
	

}