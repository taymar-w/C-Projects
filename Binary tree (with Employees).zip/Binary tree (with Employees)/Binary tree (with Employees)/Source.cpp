#include <iostream>
#include <string>
using namespace std;

class Node {
public:
	int height,weight, age;
	string name;
	Node* left;
	Node* right;
	Node() {}
	Node(int h, int w, int a, string n) { name = n; age = a; weight = w; height = h;  left = nullptr; right = nullptr; }
};

class Tree {
	Node* Insert(Node* node, int h, int w, int a, string n) {
		if (node == nullptr) {
			Node* newNode = new Node(h,w,a,n);
			node = newNode;
		}
		else if (n <= node->name) {
			node->left = Insert(node->left, h, w, a, n);
		}
		else {
			node->right = Insert(node->right, h, w, a, n);
		}
		return node;
	}
	void PrintPreOrder(Node* node) {
		if (node != nullptr) {
			cout << "| NAME: " << node->name << " AGE: " << node->age << " HEIGHT: " << node->height << " WEIGHT: " << node->weight << " |\n";
			PrintPreOrder(node->left);
			PrintPreOrder(node->right);
		}
	}
	void PrintInOrder(Node* node) {
		if (node != nullptr) {
			PrintInOrder(node->left);
			cout << "| NAME: " << node->name << " AGE: " << node->age << " HEIGHT: " << node->height << " WEIGHT: " << node->weight << " |\n";
			PrintInOrder(node->right);
		}
	}
	void PrintPostOrder(Node* node) {
		if (node != nullptr) {
			PrintPostOrder(node->left);
			PrintPostOrder(node->right);
			cout <<"| NAME: "<< node->name << " AGE: "<<node->age<<" HEIGHT: "<<node->height<<" WEIGHT: "<< node->weight<<" |\n";
		}
	}
	void PrintLevelOrder(Node* node) {
		if (node != nullptr) {
			cout << "| NAME: " << node->name << " AGE: " << node->age << " HEIGHT: " << node->height << " WEIGHT: " << node->weight << " |\n";
			PrintLevelOrder(node->right);
			PrintLevelOrder(node->left);
		}
	}
	bool Search(Node* node, string x) {
		if (node == nullptr) { cout << "Not Found!\n"; return false; }
		else if (node->name == x) {cout << "Found! :" << x <<endl; return true;  }
		else if (x < node->name)return Search(node->left, x);
		else return Search(node->right, x);
	}
	Node* SearchBack(Node* node, string x) {
		if (node == nullptr) return false;
		else if (node->name == x)return node;
		else if (x < node->name)return SearchBack(node->left, x);
		else return SearchBack(node->right, x);
	}
	Node* Delete(Node* node, string x) {
		if (node == nullptr) { cout << "No tree"; }
		else if (x < node->name) {
			node->left = Delete(node->left, x);
		}
		else if (x > node->name) {
			node->right = Delete(node->right, x);
		}
		else {
			if (node->left == nullptr && node->right == nullptr) {
				delete node;
				node = nullptr;
			}
			else if (node->left == nullptr) {
				Node* temp = node;
				node = node->right;
				delete temp;
			}
			else if (node->right == nullptr) {
				Node* temp = node;
				node = node->right;
				delete temp;
			}
			else {
				Node* temp = FindMinNode(node->right);
				node->age = temp->age;
				node->right = Delete(node->right, temp->name);
			}
		}
		return node;
	}
	Node* FindMinNode(Node* node) {
		Node* temp = node;
		while (temp->left != nullptr) temp = temp->left;
		return temp;
	}
	Node* DeleteBack(Node* node, string x) {
		if (node == nullptr) { cout << "No tree"; }
		else if (x < node->name) {
			node->left = DeleteBack(node->left, x);
		}
		else if (x > node->name) {
			node->right = DeleteBack(node->right, x);
		}
		else {
			if (node->left == nullptr && node->right == nullptr) {
				delete node;
				node = nullptr;
			}
			else if (node->left == nullptr) {
				Node* temp = node;
				node = node->right;
				delete temp;
			}
			else if (node->right == nullptr) {
				Node* temp = node;
				node = node->right;
				delete temp;
			}
			else {
				Node* temp = FindMinNode(node->right);
				node->age = temp->age;
				node->right = DeleteBack(node->right, temp->name);
			}
		}
		return node;
	}
public:
	Node* root;
	Tree() { root = nullptr; }
	void Insert(int h, int w, int a, string n) {
		root = Insert(root, h, w, a, n);
	}
	bool Search(string x) { cout << "Searching for: " <<"'" <<x<<"'"<<endl;  return Search(root, x); }
	Node* SearchBack(string x) { cout << "Searching back for: " << "'" << x << "'"; return SearchBack(root, x); }
	Node* Delete(string x) { cout << "Deleting!:" << "'" << x << "'" << endl; cout<< "'" << x << "'" << " has been deleted!\n"; return Delete(root, x);  }
	Node* DeleteBack(string x) { cout << "Deleting Back!:" << "'" << x << "'"<< endl; cout<< "'" << x << "'" << " has been deleted back!\n"; return DeleteBack(root, x); }
	void PrintPreOrder() {  cout << "PreOrder: "; cout << endl; PrintPreOrder(root); cout << endl; }
	void PrintInOrder() {  cout << "InOrder: "; cout << endl; PrintInOrder(root); cout << endl; }
	void PrintPostOrder() {  cout << "PostOrder: ";cout << endl;  PrintPostOrder(root); cout << endl; }
	void PrintLevelOrder() { cout << "LevelOrder: "; cout << endl;  PrintLevelOrder(root); cout << endl; }
	string Minimum() {
		if (!root) { cout << "Empty Tree" << endl;  }
		Node* temp = root;
		while (temp->left != nullptr)temp = temp->left;
		return temp->name;
	}
	string Maximum() {
		if (!root) { cout << "Empty Tree" << endl;  }
		Node* temp = root;
		while (temp->right != nullptr)temp = temp->right;
		return temp->name;
	}
};

int main() {
	Tree* tree = new Tree();
	tree->Insert(5, 190, 22, "Alan");
	tree->Insert(4, 122, 21, "Bob");
	tree->Insert(6,231,45,"Tim");
	tree->Insert(5, 231, 25, "Jim");
	tree->Insert(7, 231, 15, "Tina");
	tree->Insert(4, 231, 43, "Sam");
	tree->Insert(5, 100, 4, "Tom");
	tree->Insert(6, 110, 6, "Rick");
	tree->Insert(4, 140, 16, "Candace");

	tree->PrintInOrder();
	tree->PrintPostOrder();
	tree->PrintPreOrder();
	tree->PrintLevelOrder();

	cout <<"Maximum: "<< tree->Maximum() << endl;
	cout <<"Minimum: "<< tree->Minimum() << endl;
	tree->Search("Tim");
	tree->Search("Tina");
	tree->Search("Tori");
	cout << " Here's the value: " << tree->SearchBack("Tina") << endl;
	tree->Delete("Bob");
	tree->DeleteBack("Candace");
	tree->PrintPreOrder();
	getchar();
}